# Shell Scripts Menu

This folder contains grouped shell scripts with menu navigation.

- **Backup**: scripts related to backup
- **Database**: scripts related to database
- **Dependencies**: scripts related to dependencies
- **Deploy**: scripts related to deploy
- **Docker**: scripts related to docker
- **Git**: scripts related to git
- **Misc**: scripts related to misc
- **Tests**: scripts related to tests
