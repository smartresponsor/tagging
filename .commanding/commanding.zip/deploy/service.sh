while true; do
  clear
  echo -e "\e[1m"
  echo -e " Service :"
  echo -e " -------------------"
  echo -e "\e[0m \e[32m"
  echo -e " 1 Fixture PowerCycle"
  echo -e " 2 Add new Fixture"
  echo -e '\e[0m \e[1m'
  echo -e " ------------------------"
  echo -e " 0 Exit to main menu... "
  echo -e '\e[0m \e[32m'

  read -r -n 1 -s -p " Enter action number or press Space for Exit:" action

  trimmed_action=$(echo $action | xargs)

  if [ -z "$trimmed_action" ]; then
    bash
  fi

  case $action in
  1)
    echo -e "    Routes..."
    php bin/console debug:router
    ;;
  2)
    echo -e "    Check Route access by routeName (guest access)..."
    read -p "    Enter Route Name: " routeName
    php bin/console debug:router --format=md --show-controllers $routeName
    ;;
  3)
    echo -e "    Check Route access by routeName and user..."
    read -p "    Enter Route Name: " routeName
    read -p "    Enter User Name: " userName
    php bin/console debug:router --format=md --show-controllers $routeName $userName
    ;;
  4)
    echo ''
    read -p "    Enter part of Route Name: " partialRouteName
    php bin/console debug:router --format=md --show-controllers | grep -E "($partialRouteName)|(^ --------------)|(^ Name)"
    ;;
  5)
    echo -e "Search Route by exact name..."
    read -p "Enter exact Route Name: " exactRouteName
    php bin/console debug:router --format=md --show-controllers | grep -E "($exactRouteName)|(^ --------------)|(^ Name)" | awk '{if (/^ /) {print "\t" $0} else if (/^ -/) {print "\n\t" $0} else {print}}'
    ;;
  0)
    echo -e "Go back to main menu"
    bash "$COMMANDING_DIR/commanding.sh" || true
    return 0
    ;;
  *) echo -e "\e[31m Incorrect\e[0m" ;;
  esac
    if [ $? -ne 0 ]; then
      # read -p "Произошла ошибка. Нажмите Enter для продолжения."
    bash || true
    return 0
    fi
done
