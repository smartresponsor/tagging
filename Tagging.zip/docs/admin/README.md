# SmartResponsor — Tag Admin (E10)
Minimal, no-build HTML/JS UI. Open `admin/index.html` in a browser.
Configure the API base URL at the top of the page. Uses fetch() to call the HTTP endpoints.

## E16 Admin UI v2
- Bulk import: paste NDJSON and click Import — shows job id.
- Merge/Split/Resolve: simple forms under the table.
- Works with API base set in header controls; actor id via X-Actor-Id.
