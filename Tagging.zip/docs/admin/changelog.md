
## E22 UI v3
- Search + pagination without build tools.
- Bulk merge to target tag.
- Bulk relabel via PATCH /tag/{id}.
- Export current list to NDJSON.
