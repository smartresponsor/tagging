# Tag Demo Seed

## Run
```bash
export DB_DSN="pgsql:host=localhost;port=5432;dbname=app"
export DB_USER="app"
export DB_PASS="app"
export TENANT="demo"
php tools/seed/tag-seed.php
```

## Clear
```bash
php tools/seed/tag-clear.php
```

Generated: 2025-10-27T20:19:32.645120
