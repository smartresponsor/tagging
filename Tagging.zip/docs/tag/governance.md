# Governance

Policy fields: allowedPrefixes, deniedPrefixes, allowedSlugs, maxLength.
Validation on create; audit iterates all tags and reports violations.
