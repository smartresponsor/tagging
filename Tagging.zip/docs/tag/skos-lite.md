# SKOS-lite for SmartResponsor/Tag

We use altLabel (synonyms), broader, related, and schemes.
