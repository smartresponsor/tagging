<?php
# Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);
namespace App\Service\Tag;

use App\ServiceInterface\Tag\TagRepositoryInterface as TagRepositoryContract;

final class TagPropagationService {
    public function __construct(private TagRepositoryContract $repo){}

    public function putClassificationForTag(string $tenantId, string $tagId, string $key, string $value): void {
        $this->repo->putClassification($tenantId, UlidGenerator::generate(), 'tag', $tagId, $key, $value);
    }

    public function putClassificationForScheme(string $tenantId, string $schemeName, string $key, string $value): void {
        $this->repo->putClassification($tenantId, UlidGenerator::generate(), 'scheme', $schemeName, $key, $value);
    }

    public function replayForTag(string $tenantId, string $tagId): int {
        $this->repo->clearEffectsForSource($tenantId, 'tag', $tagId);
        $class = $this->repo->listClassifications($tenantId, 'tag', $tagId);
        if (!$class) return 0;
        $pairs = $this->repo->listAssignmentsByTag($tenantId, $tagId);
        $n=0;
        foreach ($pairs as $p) {
            foreach ($class as $c) {
                $this->repo->putEffect($tenantId, UlidGenerator::generate(), $p['assigned_type'], $p['assigned_id'], $c['key'], $c['value'], 'tag', $tagId);
                $n++;
            }
        }
        return $n;
    }

    public function replayForScheme(string $tenantId, string $schemeName): int {
        $this->repo->clearEffectsForSource($tenantId, 'scheme', $schemeName);
        $class = $this->repo->listClassifications($tenantId, 'scheme', $schemeName);
        if (!$class) return 0;
        $tags = $this->repo->listTagsByScheme($tenantId, $schemeName);
        $n=0;
        foreach ($tags as $t) {
            $pairs = $this->repo->listAssignmentsByTag($tenantId, $t['tag_id']);
            foreach ($pairs as $p) {
                foreach ($class as $c) {
                    $this->repo->putEffect($tenantId, UlidGenerator::generate(), $p['assigned_type'], $p['assigned_id'], $c['key'], $c['value'], 'scheme', $schemeName);
                    $n++;
                }
            }
        }
        return $n;
    }

    public function dryRunForTag(string $tenantId, string $tagId): array {
        $class = $this->repo->listClassifications($tenantId, 'tag', $tagId);
        $pairs = $this->repo->listAssignmentsByTag($tenantId, $tagId);
        $out=[];
        foreach ($pairs as $p) foreach ($class as $c) $out[] = $p['assigned_type'].':'.$p['assigned_id'].' -> '.$c['key'].'='.$c['value'];
        return $out;
    }
}
